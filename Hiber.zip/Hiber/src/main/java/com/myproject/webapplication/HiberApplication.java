package com.myproject.webapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiberApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiberApplication.class, args);
	}

}
