package com.myproject.webapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiberApplicationTests {

	@Test
	void contextLoads() {
	}

}
